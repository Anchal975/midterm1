package com.example.coursesregisteration;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
 TextView welcomeStudent,fees,hours, totalFees,totalHours;
 Spinner sp;
 RadioButton rb1, rb2;
 CheckBox op1, op2;
 Button add;
 ArrayList<String>courseNames=new ArrayList<>();
 ArrayList<Courses>courseList=new ArrayList<>();
 public static double originaleFees = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        welcomeStudent=findViewById(R.id.welcomeMsg);
        welcomeStudent.setText("Welcome" +LoginActivity.studentName);
        fillData();

        fees=findViewById(R.id.txtFee);
        hours=findViewById(R.id.txtHour);
        totalFees=findViewById(R.id.txtTotalFee);
        totalHours=findViewById(R.id.txtTotalHours);
        sp=findViewById(R.id.courseSp);
        rb1=findViewById(R.id.rbGrad);
        rb2=findViewById(R.id.rbUngrad);
        op1=findViewById(R.id.cb1);
        op2=findViewById(R.id.cb2);
        add=findViewById(R.id.addBtn);

        ArrayAdapter aa= new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,courseNames);
        sp.setAdapter(aa);

        sp.setOnItemSelectedListener(this);
        rb1.setOnClickListener(new ButtonsHandlings());
        rb2.setOnClickListener(new ButtonsHandlings());

        op1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                double txtTotalFee = Double.parseDouble(totalFees.getText().toString());
                if(op1.isChecked())
                    txtTotalFee+=1000;
                else
                    txtTotalFee-=1000;
                 totalFees.setText(String.valueOf(txtTotalFee));
            }
        });
        op2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                double txtTotalFee = Double.parseDouble(totalFees.getText().toString());
                if(op2.isChecked())
                    txtTotalFee+=700;
                else
                    txtTotalFee-=700;
                totalFees.setText(String.valueOf(txtTotalFee));
            }
        });
    }
    public void fillData(){
        courseList.add(new Courses("Java","1300","6"));
        courseList.add(new Courses("Swift","1500","5"));
        courseList.add(new Courses("iOS","1350","5"));
        courseList.add(new Courses("Android","1400","7"));
        courseList.add(new Courses("Database","1000","4"));

        for(int i=0;i<courseList.size();i++)
           courseNames.add(courseList.get(i).getCourseName());

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        fees.setText(String.valueOf(courseList.get(i).getCourseFee()));
        totalFees.setText(String.valueOf(courseList.get(i).getCourseFee()));
        hours.setText(String.valueOf(courseList.get(i).getCourseHour()));
        totalHours.setText(String.valueOf(courseList.get(i).getCourseHour()));

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    private class ButtonsHandlings implements View.OnClickListener{

        @Override
        public void onClick(View view) {
           double oldFees = 0;
            switch(view.getId()){
                case R.id.rbUngrad:

                    totalFees.setText(String.valueOf(oldFees));
                    totalHours.setText(String.valueOf(oldFees));

                case R.id.rbGrad:

                    totalFees.setText(String.valueOf(oldFees));
                    totalHours.setText(String.valueOf(oldFees));

                case R.id.addBtn:
                    double totalFee = Double.parseDouble(fees.getText().toString());
                    double totalHour = Double.parseDouble(hours.getText().toString());
                    if(op2.isChecked());
                     totalFee+=700;

                     totalFees.setText(String.format("%.2f",totalFee));



            }

        }
    }
}
